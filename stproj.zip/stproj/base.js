const $ = {}

window.$ = $