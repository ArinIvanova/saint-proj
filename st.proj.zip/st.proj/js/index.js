console.log('Hellow world!');

const myFirstvARIABLE = 10

console.log(myFirstvARIABLE)

function creatModal(text) {
const modal = document.createElement('div');
modal.classList.add('first');
modal.innerText = text;

    return modal;
}

document.querySelector('#app').appendChild(creatModal('Red'));
document.querySelector('#app').appendChild(creatModal('Green'));
document.querySelector('#app').appendChild(creatModal('Blue'));

import { WINDOWS } from "./build/constants";

document.querySelector('red').addEventListener('click', () => {
state.currentModalType = R_OPENED
});
document.querySelector('green').addEventListener('click', () => {
    state.currentModalType = G_OPENED
    });
    document.querySelector('blue').addEventListener('click', () => {
        state.currentModalType = B_OPENED
        });
